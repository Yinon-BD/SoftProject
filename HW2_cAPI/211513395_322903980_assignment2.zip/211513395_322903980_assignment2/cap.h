# ifndef CAP_H
# define CAP_H

double **getKmeans(double **dps, double **centroidsMean, int *dp2c, int K, int N, int d, int iter, double epsilon);

# endif