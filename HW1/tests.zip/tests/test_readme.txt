1. k=3, n=800, d=3, max_iter = 600
2. k=7, n=430, d=11, max_iter = not provided
3. k=15, n=5000, d=5, max_iter = 300